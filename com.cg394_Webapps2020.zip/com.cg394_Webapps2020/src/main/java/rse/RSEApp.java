package rse;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import java.util.HashSet;
import java.util.Set;

@ApplicationPath("/")
public class RSEApp extends Application{
    @Override
    public Set<Class<?>> getClasses(){
        final Set<Class<?>> classes;
        classes = new HashSet<>();
        classes.add(RSECurrency.class);
        return classes;        
    }
}
