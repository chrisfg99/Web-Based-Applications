package rse;

import java.util.HashMap;
import javax.ejb.Singleton;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/conversion")
@Singleton
public class RSECurrency {
    HashMap<String,Currency> currencys;

    public RSECurrency() {
        this.currencys = new HashMap<>();
        Currency BritishPound = new Currency(1,1.16,1.39,"GBP");
        currencys.put("GBP",BritishPound);
        Currency Euro = new Currency(0.86,1,1.2,"EUR");
        currencys.put("EUR",Euro);
        Currency USDollar = new Currency(0.72,0.83,1,"USD");
        currencys.put("USD",USDollar);
    }
    
    @Path("/(currency1)/(currency2)")
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @GET
    public Response getRates(@PathParam("currency1") String currency1, @PathParam("currency2") String currency2){
        Currency c =currencys.get(currency1);
        System.out.print(c.getName());
        if(c==null){
            return Response.status(Response.Status.NOT_FOUND).build();
            
        }
        else{
            System.out.print(currency2);
            if ("GBP".equals(currency2)){
                System.out.print("GBP");
                return Response.ok(c.getGBP()).build();
            }
            else if("EUR".equals(currency2)){
                System.out.print("EUR");
                return Response.ok(c.getEUR()).build();
            }
            else if("USD".equals(currency2)){
                System.out.print("USD");
                return Response.ok(c.getUSD()).build();
            }
            else{
                return Response.status(Response.Status.NOT_FOUND).build();
            }
        }
    }
    
    @Path("/(currency1)/(currency2)/{amount}")
    @Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
    @GET
    public Response getAmount(@PathParam("currency1") String currency1, @PathParam("currency2") String currency2, @PathParam("amount") int amount){
        Currency c =currencys.get(currency1);
        System.out.print(c.getName());
        if(c==null){
            return Response.status(Response.Status.NOT_FOUND).build();
            
        }
        else{
            System.out.print(currency2);
            if ("GBP".equals(currency2)){
                amount=amount*(int)c.getGBP();
                return Response.ok(amount).build();
            }
            else if("EUR".equals(currency2)){
                amount=amount*(int)c.getEUR();
                return Response.ok(amount).build();
            }
            else if("USD".equals(currency2)){
                amount=amount*(int)c.getUSD();
                return Response.ok(amount).build();
            }
            else{
                return Response.status(Response.Status.NOT_FOUND).build();
            }
        }
    }
}
