
package rse;

import javax.xml.bind.annotation.XmlAttribute;

public class Currency {
    double GBP;
    double EUR;
    double USD;
    String name;

    public Currency(double GBP, double EUR, double USD, String name) {
        this.GBP = GBP;
        this.EUR = EUR;
        this.USD = USD;
        this.name = name;
    }
    
    public Currency(){}
    
    @XmlAttribute
    public double getGBP() {
        return GBP;
    }

    public void setGBP(double GBP) {
        this.GBP = GBP;
    }
    
    @XmlAttribute
    public double getEUR() {
        return EUR;
    }

    public void setEUR(double EUR) {
        this.EUR = EUR;
    }
    
    @XmlAttribute
    public double getUSD() {
        return USD;
    }

    public void setUSD(double USD) {
        this.USD = USD;
    }
    
    @XmlAttribute
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    
}
