package com.cg394.webapps2020.jsf;

import com.cg394.webapps2020.ejb.DepositService;
import com.cg394.webapps2020.entity.SystemDeposit;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;


@Named
@RequestScoped
public class DepositBean {

    @EJB
    DepositService dpstSrv;
    
    Long id;
    Date date;
    double amount;
    String email;
    String currency;
    String fromName;
    String toName;
    String status;

    public DepositBean() {
    }

    public String newDeposit() {
        date=java.util.Calendar.getInstance().getTime();
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        email=request.getRemoteUser();
        if(dpstSrv.userExist(toName)==1){
            // if GBP do normal
             if(currency.equals("GBP")){
                if(dpstSrv.checkBalance(email,amount)==1){
                    dpstSrv.newDeposit(date, amount, currency, email, toName, "Awaiting Confirmation");
                }
            }//If euros convert GBP to euros
            else if (currency.equals("EUR")){
                double inGBP=(double) (this.amount*1.16);
                if(dpstSrv.checkBalance(email,inGBP)==1){
                    dpstSrv.newDeposit(date, amount, currency, email, toName, "Awaiting Confirmation");
                }
            }
            //if US Dollars convert GBP to US Dollars
            else if (currency.equals("USD")){
                double inGBP=(double) (this.amount*1.39);
                if(dpstSrv.checkBalance(email,inGBP)==1){
                    dpstSrv.newDeposit(date, amount, currency, email, toName, "Awaiting Confirmation");
                }
            }
        }
        return "/users/user";
    }
    
    public String requestDeposit() throws IOException {
        date=java.util.Calendar.getInstance().getTime();
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        email=request.getRemoteUser();
        if(dpstSrv.userExist(fromName)==1){
            if(currency.equals("GBP")){
                if(dpstSrv.checkBalance(fromName,amount)==1){
                    dpstSrv.newDeposit(date, amount, currency, fromName, email, "Requested");
                }
            }
            else if (currency.equals("EUR")){
                double inGBP=(double) (this.amount*0.86);
                if(dpstSrv.checkBalance(fromName,inGBP)==1){
                    dpstSrv.newDeposit(date, amount, currency, fromName, email, "Requested");
                }
            }
            else if (currency.equals("USD")){
                double inGBP=(double) (this.amount*0.72);
                if(dpstSrv.checkBalance(fromName,inGBP)==1){
                    dpstSrv.newDeposit(date, amount, currency, fromName, email, "Requested");
                }
            }
        }
        return "/users/user";
    }
    
    public String acceptDeposit() {
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        email=request.getRemoteUser();
        dpstSrv.acceptDeposit(id,email);
        return "/users/user";
    }
    
    public String rejectDeposit() {
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        email=request.getRemoteUser();
        dpstSrv.rejectDeposit(id,email);
        return "/users/user";
    }
    
    public double getCurrentBalance(){
        date=java.util.Calendar.getInstance().getTime();
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        email=request.getRemoteUser();
        return dpstSrv.getBalance(email); 
    }
    
    public DepositService getDpstSrv() {
        return dpstSrv;
    }

    public void setDpstSrv(DepositService dpstSrv) {
        this.dpstSrv = dpstSrv;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getAmount() {
        return amount;
    }
    
    public void setAmount (double amount) {
        this.amount = amount;
    }
    
    public String getCurrency() {
        return currency;
    }
    
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getFromName() {
        return fromName;
    }

    public void setFromName(String fromName) {
        this.fromName = fromName;
    }

    public String getToName() {
        return toName;
    }

    public void setToName(String toName) {
        this.toName = toName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<SystemDeposit> getDepositList() {
        HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        String username=request.getRemoteUser();
        return dpstSrv.getDepositList(username);
    }
    
    public List<SystemDeposit> getAllDeposits() {
        return dpstSrv.getAllDeposit();
    }
}

//Code that should be used by the rse to check conversions
//String url;
//url = "http://localhost:10000/com.cg394_Webapps2020/conversion/";
//String charset = "UTF-8";
//String currency1 = currency;
//String currency2 = "GBP";
//int amount1 = this.amount;

//String query = String.format("/currency1=%s/currency2=%s/amount1=%s", 
//     URLEncoder.encode(currency1, charset), 
//     URLEncoder.encode(currency2, charset),
//     amount1);
//URLConnection connection = new URL(url + "?" + query).openConnection();
//connection.setRequestProperty("Accept-Charset", charset);
//InputStream response = connection.getInputStream();
//this.amount=response.read();
//if(dpstSrv.checkBalance(fromName,amount)==1){
//    dpstSrv.newDeposit(date, amount, "GBP", fromName, email, "Requested");
