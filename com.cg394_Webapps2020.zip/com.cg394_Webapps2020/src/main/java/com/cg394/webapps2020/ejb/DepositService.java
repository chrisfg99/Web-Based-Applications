package com.cg394.webapps2020.ejb;

import com.cg394.webapps2020.entity.SystemDeposit;
import com.cg394.webapps2020.entity.SystemUser;
import com.cg394.webapps2020.entity.SystemUserGroup;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Stateless
public class DepositService {

    @PersistenceContext
    EntityManager em;

    public DepositService() {
    }

    public DepositService(EntityManager em) {
        this.em = em;
    }

    public void newDeposit(Date date, double amount, String currency, String fromName, String toName, String status)
    {
        SystemDeposit deposit = new SystemDeposit(date,amount,currency,fromName,toName,status);
        em.persist(deposit);
    }
    
    public void acceptDeposit(Long id, String username)
    {
        //Get deposit
        SystemDeposit deposit;
        List list = em.createNamedQuery("getDeposit").setParameter("id",id).getResultList();
        deposit = (SystemDeposit) (list.get(0));
        if(username.equals(deposit.getToName())){
            if("Awaiting Confirmation".equals(deposit.getStatus())){
                //Edit User Sending money
                List<SystemUser> senderList = em.createNamedQuery("findUsers").setParameter("email",deposit.getFromName()).getResultList();
                SystemUser sender = senderList.get(0);
                //Edit User recieving money
                List<SystemUser> recieverList = em.createNamedQuery("findUsers").setParameter("email",username).getResultList();
                SystemUser reciever = recieverList.get(0);
                //get user amount, if it is GBP nothing will change
                double inGBP=deposit.getAmount();
                // if its euros convert it back to GBP
                if (deposit.getCurrency().equals("EUR")){
                    inGBP=(double) (deposit.getAmount()*0.86);
                }
                // if its us dollars convert it back to GBP
                else if (deposit.getCurrency().equals("USD")){
                    inGBP=(double) (deposit.getAmount()*0.72);
                }
                if(inGBP<=(sender.getBalance())){
                    //change status to accepted
                    deposit.acceptDeposit();
                    em.persist(deposit);
                    //set Reciever balance
                    reciever.setBalance(reciever.getBalance()+inGBP);
                    //set Sender balance
                    sender.setBalance(sender.getBalance()-inGBP);
                }
                else{
                    deposit.setStatus("Error: Payee can't pay");
                    em.persist(deposit);
                }
            }
        }
        else if(username.equals(deposit.getFromName())){
            if("Requested".equals(deposit.getStatus())){
                //Edit User Sending money
                List<SystemUser> senderList = em.createNamedQuery("findUsers").setParameter("email",username).getResultList();
                SystemUser sender = senderList.get(0);
                //Edit User recieving money
                List<SystemUser> recieverList = em.createNamedQuery("findUsers").setParameter("email",deposit.getToName()).getResultList();
                SystemUser reciever = recieverList.get(0);
                double inGBP=deposit.getAmount();
                if (deposit.getCurrency().equals("EUR")){
                    inGBP=(double) (deposit.getAmount()*0.86);
                }
                else if (deposit.getCurrency().equals("USD")){
                    inGBP=(double) (deposit.getAmount()*0.72);
                }
                if(inGBP<=(sender.getBalance())){
                    //change status to accepted
                    deposit.acceptDeposit();
                    em.persist(deposit);
                    //set Reciever balance
                    reciever.setBalance(reciever.getBalance()+inGBP);
                    //set Sender balance
                    sender.setBalance(sender.getBalance()-inGBP);
                }
                else{
                    deposit.setStatus("Error: Payee can't pay");
                    em.persist(deposit);
                }
            }
        }
    }
    
    public void rejectDeposit(Long id, String username)
    {
        SystemDeposit deposit;
        List list = em.createNamedQuery("getDeposit").setParameter("id",id).getResultList();
        deposit = (SystemDeposit) (list.get(0));
        if(username.equals(deposit.getToName())){
            if("Awaiting Confirmation".equals(deposit.getStatus())){
                deposit.rejectDeposit();
                em.persist(deposit);
            }
        }
        else if(username.equals(deposit.getFromName())){
            if("Requested".equals(deposit.getStatus())){
                deposit.rejectDeposit();
                em.persist(deposit);
            }
        }
    }
    
    public List<SystemDeposit> getDepositList(String username) {
        return em.createNamedQuery("findUsersDeposits").setParameter("email",username).getResultList();
    }
    
    public List<SystemDeposit> getAllDeposit() {
        return em.createNamedQuery("findAllDeposits").getResultList();
    }
    
    public int userExist(String email) {
        List<SystemUser> list = em.createNamedQuery("findUsers").setParameter("email",email).getResultList();
        if(list.isEmpty()==true) {
            return 0;
        } else {
            SystemUser user=list.get(0);
            if(user.getUsername().equals(email)){
                return 1;
            }
            else{
                return 0;
            }
        }
    }
    
    public int checkBalance(String email, double amount) {
        System.out.print(email);
        List<SystemUser> list = em.createNamedQuery("findUsers").setParameter("email",email).getResultList();
        SystemUser user = list.get(0);
        double balance= user.getBalance();
        double sum=balance-amount;
        if(sum<0) {
            return 0;
        } else {
            return 1;
        }
    }
    
    public double getBalance(String email){
        List<SystemUser> list = em.createNamedQuery("findUsers").setParameter("email",email).getResultList();
        SystemUser user = list.get(0);
        return user.getBalance();
    }

    public EntityManager getEm() {
        return em;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }
}
