
package com.cg394.webapps2020.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.validation.constraints.NotNull;

@NamedQueries({
    @NamedQuery(name="findAllDeposits", query="SELECT c FROM SystemDeposit c "),
    @NamedQuery(name="findUsersDeposits", query="SELECT c FROM SystemDeposit c WHERE c.fromName=:email OR c.toName=:email"),
    @NamedQuery(name="getDeposit", query="SELECT c FROM SystemDeposit c WHERE c.id=:id"),
    @NamedQuery(name="findUsers", query="SELECT c FROM SystemUser c WHERE c.username=:email ")
})
@Entity
public class SystemDeposit implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @NotNull
    Date date;

    @NotNull
    double amount;

    @NotNull
    String currency;

    //These strings should be user classes
    //However with the time limit refactoring wasn't an option
    //Thi is as by the time I relalised it was too close to the Late Deadline
    @NotNull
    String fromName;
    
    @NotNull
    String toName;
    
    @NotNull
    String status;

    public SystemDeposit(Date date, double amount, String currency, String fromName, String toName, String status) {
        this.date = date;
        this.amount = amount;
        this.currency = currency;
        this.fromName = fromName;
        this.toName = toName;
        this.status = status;
    }
    
    public SystemDeposit(){
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getFromName() {
        return fromName;
    }

    public void setFromName(String fromName) {
        this.fromName = fromName;
    }

    public String getToName() {
        return toName;
    }

    public void setToName(String toName) {
        this.toName = toName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public void acceptDeposit() {
        this.status = "Accepted";
    }
    
    public void rejectDeposit() {
        this.status = "Rejected";
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.id);
        hash = 97 * hash + Objects.hashCode(this.date);
        hash = 97 * hash + Objects.hashCode(this.amount);
        hash = 97 * hash + Objects.hashCode(this.currency);
        hash = 97 * hash + Objects.hashCode(this.fromName);
        hash = 97 * hash + Objects.hashCode(this.status);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SystemDeposit other = (SystemDeposit) obj;
        if (!Objects.equals(this.amount, other.amount)) {
            return false;
        }
        if (!Objects.equals(this.currency, other.currency)) {
            return false;
        }
        if (!Objects.equals(this.fromName, other.fromName)) {
            return false;
        }
        if (!Objects.equals(this.toName, other.toName)) {
            return false;
        }
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        if (!Objects.equals(this.date, other.date)) {
            return false;
        }
        if (!Objects.equals(this.status, other.status)) {
            return false;
        }
        return true;
    }
    
    
}
