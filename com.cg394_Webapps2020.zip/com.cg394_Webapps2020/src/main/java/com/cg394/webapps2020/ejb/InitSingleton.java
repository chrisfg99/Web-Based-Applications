/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cg394.webapps2020.ejb;

import com.cg394.webapps2020.entity.SystemUser;
import java.lang.String;
import com.cg394.webapps2020.ejb.UserService;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author chris
 */
@Startup
@Singleton
public class InitSingleton {

    @EJB
    UserService userService;

    
    
    @PostConstruct
    public void dbInit() {
        System.out.println("At startup: Initialising Database with rows (x,y) with initial values 0");
        
            String username ="admin1";
            String userpassword ="admin1";
            String name ="Chris";
            String surname ="Greer";
            userService.registerAdmin(username, userpassword, name, surname,1000);

        
    }

   
 
}
